# คู่มือขึ้น Host — ระบบแจ้งซ่อม (maintenance-system)

## ข้อกำหนด
- PHP 8.0+ (เปิด extension: pdo_mysql, mbstring, zip, gd, xml)
- MySQL/MariaDB + Apache (รองรับ .htaccess)
- ต้องวางโฟลเดอร์ชื่อ `maintenance-system` ไว้ใต้ root ของเว็บ
  เพราะโค้ดฝัง path `/maintenance-system/...` ไว้ (157 จุด)
  เช่น `public_html/maintenance-system/` → เข้าที่ `https://โดเมน/maintenance-system/login.php`

## ขั้นตอน
1. สร้างฐานข้อมูล + user ใน cPanel/DirectAdmin (MySQL Databases) แล้วจดชื่อ/user/รหัสผ่าน
2. phpMyAdmin → เลือกฐานข้อมูล → Import
   - **แนะนำ:** export ฐานข้อมูลจริงจากเครื่องคุณ (phpMyAdmin → Export → SQL) แล้ว import ตัวนั้น
     เพราะไฟล์ `database/maintenance.sql` สร้างแค่ ~12 ตาราง แต่ระบบใช้ ~40 ตาราง
     (parts, purchase, approval, RBAC, PM ฯลฯ)
3. อัปโหลดโฟลเดอร์ `maintenance-system` (File Manager หรือ FTP) ไปที่ `public_html/`
4. ในโฟลเดอร์ `config/` คัดลอก `database.local.php.example` → `database.local.php`
   แล้วใส่ค่า DB ของ host
5. ตั้งสิทธิ์เขียนได้ (755 หรือ 775) ให้: `uploads/`, `assets/uploads/`, `storage/backups/`
6. เปิด `https://โดเมน/maintenance-system/login.php` แล้วทดสอบล็อกอิน
7. ถ้าไม่มี user admin: สร้างผ่าน phpMyAdmin (ตาราง users, รหัสผ่านใช้ password_hash)
   อย่าอัปโหลดสคริปต์ create_admin/reset password ขึ้น host

## สิ่งที่ตัดออกจากแพ็กเกจแล้ว (เพื่อความปลอดภัย)
- `_dev_tools`, create_admin.php (มีรหัสผ่านเริ่มต้น 1234), hash.php, reset_*password.php, fix_testuser.php, test_database.php
- ไฟล์ install_*.php, repair_database_notification.php, notification_test.php
- โฟลเดอร์ backup ของ theme/assets เก่า
- เพิ่ม .htaccess บล็อก config/, database/, storage/

## หลังขึ้นระบบ
- เปลี่ยนรหัสผ่าน admin ทันที, เปิด HTTPS
- ลบโฟลเดอร์ `database/` ออกจาก host หลัง import เสร็จ
